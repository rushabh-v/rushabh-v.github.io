__version__ = 1.1
NAME = 'facerec'
PATH = '/usr/lib/Auth/Facerec/'
LICENSE = 'GPL-3'
GIT_URL = 'http://github.com/rushabh-v/linux_face_unlock'